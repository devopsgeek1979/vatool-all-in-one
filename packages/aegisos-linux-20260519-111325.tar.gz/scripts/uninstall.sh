#!/bin/bash

set -euo pipefail

SERVICE_NAME="aegisos"
DATA_DIR="${DATA_DIR:-/var/lib/aegisos}"
LOG_DIR="${LOG_DIR:-/var/log/aegisos}"
BINARY_PATH="${BINARY_PATH:-/usr/local/bin/aegisosd}"

if [[ $EUID -ne 0 ]]; then
  echo "Run as root."
  exit 1
fi

systemctl stop "$SERVICE_NAME" >/dev/null 2>&1 || true
systemctl disable "$SERVICE_NAME" >/dev/null 2>&1 || true
rm -f "/etc/systemd/system/${SERVICE_NAME}.service"
systemctl daemon-reload

rm -f "$BINARY_PATH"

if [[ "${KEEP_DATA:-false}" != "true" ]]; then
  rm -rf "$DATA_DIR"
fi

rm -rf "$LOG_DIR"

echo "Linux uninstall completed."
