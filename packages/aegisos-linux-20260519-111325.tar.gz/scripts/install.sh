#!/bin/bash

set -euo pipefail

INSTALL_DIR="${INSTALL_DIR:-/opt/aegisos}"
DATA_DIR="${DATA_DIR:-/var/lib/aegisos}"
LOG_DIR="${LOG_DIR:-/var/log/aegisos}"
BINARY_DIR="${BINARY_DIR:-/usr/local/bin}"
SERVICE_NAME="aegisos"
SERVICE_USER="${AEGISOS_USER:-aegisos}"
SERVICE_GROUP="${AEGISOS_GROUP:-aegisos}"

if [[ $EUID -ne 0 ]]; then
  echo "Run as root."
  exit 1
fi

install_deps() {
  if command -v apt-get >/dev/null 2>&1; then
    apt-get update
    apt-get install -y ca-certificates curl jq tar
  elif command -v dnf >/dev/null 2>&1; then
    dnf install -y ca-certificates curl jq tar
  elif command -v yum >/dev/null 2>&1; then
    yum install -y ca-certificates curl jq tar
  elif command -v zypper >/dev/null 2>&1; then
    zypper --non-interactive install ca-certificates curl jq tar
  elif command -v pacman >/dev/null 2>&1; then
    pacman -Sy --noconfirm ca-certificates curl jq tar
  else
    echo "Unsupported package manager. Install: ca-certificates curl jq tar"
  fi
}

install_deps

if ! id "$SERVICE_USER" >/dev/null 2>&1; then
  useradd -r -s /bin/false "$SERVICE_USER"
fi

mkdir -p "$INSTALL_DIR" "$DATA_DIR" "$LOG_DIR"
touch "$DATA_DIR/credentials.json"
chown -R "$SERVICE_USER:$SERVICE_GROUP" "$DATA_DIR" "$LOG_DIR"
chmod 700 "$DATA_DIR"
chmod 600 "$DATA_DIR/credentials.json"

if [[ -f "$(dirname "$0")/../bin/aegisosd" ]]; then
  install -m 755 "$(dirname "$0")/../bin/aegisosd" "$BINARY_DIR/aegisosd"
elif [[ -n "${AEGISOS_BINARY_URL:-}" ]]; then
  curl -fsSL "$AEGISOS_BINARY_URL" -o "$BINARY_DIR/aegisosd"
  chmod 755 "$BINARY_DIR/aegisosd"
else
  echo "No Linux binary bundled. Set AEGISOS_BINARY_URL and rerun."
  exit 1
fi

cat > "/etc/systemd/system/${SERVICE_NAME}.service" <<UNIT
[Unit]
Description=AegisOS Security Daemon
After=network.target

[Service]
Type=simple
User=${SERVICE_USER}
Group=${SERVICE_GROUP}
ExecStart=${BINARY_DIR}/aegisosd
Restart=on-failure
RestartSec=10
Environment=AEGISOS_DATA_DIR=${DATA_DIR}
Environment=AEGISOS_LOG_DIR=${LOG_DIR}
Environment=RUST_LOG=info

[Install]
WantedBy=multi-user.target
UNIT

systemctl daemon-reload
systemctl enable "$SERVICE_NAME"
systemctl restart "$SERVICE_NAME"

echo "Linux deployment completed."
echo "Setup page: https://localhost:9443/setup"
