
# AegisOS Production Deployment Checklist

## Pre-Deployment Phase

### Code Quality & Security
- [ ] Rust stable toolchain installed (1.70+)
- [ ] cargo audit executed with no vulnerabilities
- [ ] cargo clippy passes without warnings
- [ ] All unit tests passing: `cargo test --all`
- [ ] Integration tests passing: `cargo test --test e2e_tests`
- [ ] Code review completed by 2+ engineers
- [ ] Security scanning completed

### Build & Release
- [ ] Release build completed: `cargo build --release`
- [ ] Binary stripped and optimized
- [ ] Release artifacts signed with GPG
- [ ] Docker image built and scanned with Trivy
- [ ] Changelog updated with version details
- [ ] Release notes prepared

### Infrastructure Setup
- [ ] Production environment provisioned
- [ ] Network architecture reviewed
- [ ] Load balancer configured (nginx/HAProxy)
- [ ] DNS records updated and propagated
- [ ] TLS/SSL certificates installed (valid for 1+ year)
- [ ] Firewall rules configured and tested

### Configuration Management
- [ ] Environment variables documented
- [ ] API keys/secrets stored in vault (HashiCorp/AWS Secrets Manager)
- [ ] Database connection strings validated
- [ ] Configuration files backed up
- [ ] Secrets rotation policy established

### Database Preparation
- [ ] Database created and initialized
- [ ] Migrations applied successfully
- [ ] Database backups configured
- [ ] Recovery procedures tested
- [ ] Data retention policies set
- [ ] Encryption at rest enabled

## Deployment Phase

### Pre-Flight Checks
- [ ] Verify no critical processes using port 9000/9001
- [ ] Database connectivity verified
- [ ] Network connectivity to OSV API working
- [ ] Sufficient disk space available (>10GB)
- [ ] System resources available (CPU <80%, RAM <70%)

### Application Installation
- [ ] Create system user: `useradd -r -s /bin/false aegisos`
- [ ] Create directories: `/opt/aegisos`, `/var/lib/aegisos`, `/var/log/aegisos`
- [ ] Set permissions: `chown -R aegisos:aegisos /var/lib/aegisos /var/log/aegisos`
- [ ] Deploy binaries: `sudo install -m 0755 aegisosd /usr/local/bin/`
- [ ] Install systemd service file
- [ ] Configure log rotation via logrotate

### Systemd Service Setup
- [ ] Service file in `/etc/systemd/system/aegisos.service`
- [ ] Service enabled: `systemctl enable aegisos`
- [ ] Service description and documentation added
- [ ] Restart policy configured
- [ ] Resource limits configured

### Monitoring & Logging Setup
- [ ] Prometheus metrics endpoint accessible on :9001
- [ ] Log aggregation (ELK/Splunk) configured
- [ ] Cloudwatch/Azure Monitor dashboards created
- [ ] Alert rules configured for critical metrics
- [ ] Centralized logging collection working

### Security Hardening
- [ ] SELinux/AppArmor policies applied
- [ ] Rate limiting configured (100 req/min per IP)
- [ ] DDoS protection enabled
- [ ] API authentication enforced
- [ ] Audit logging enabled and verified
- [ ] File permissions verified (644 for configs, 755 for binaries)
- [ ] CIS Benchmarks page reviewed and mapped to the deployment baseline
- [ ] Credential vault file created at `/var/lib/aegisos/credentials.json`
- [ ] First-run setup completed for Admin, Operator, and Security Consultant accounts
- [ ] Password recovery and admin reset tested

## Post-Deployment Phase

### Verification Tests
- [ ] Service starts without errors: `systemctl start aegisos`
- [ ] Health check passing: `curl http://localhost:9001/health`
- [ ] Metrics endpoint accessible: `curl http://localhost:9001/metrics`
- [ ] API responds to requests: `curl http://localhost:9000/api/v1/health`
- [ ] Logs being written: `tail -f /var/log/aegisos/app.log`
- [ ] IPC socket created: `ls -la /tmp/aegisos.sock`
- [ ] HTTPS setup flow reachable at `https://localhost:9443/setup`
- [ ] CIS Benchmarks page reachable at `https://localhost:9443/cis-benchmarks`
- [ ] Password reset flow verified for normal users and admins

### Functional Testing
- [ ] Perform test vulnerability scan
- [ ] Verify database storage of results
- [ ] Test audit log generation
- [ ] Verify cryptographic operations
- [ ] Test API endpoints with authentication
- [ ] Check concurrent scan handling

### Performance Baseline
- [ ] Record CPU usage at idle
- [ ] Record memory usage at baseline
- [ ] Document response times for API calls
- [ ] Measure scan throughput
- [ ] Establish latency baseline (p50, p95, p99)

### Monitoring Validation
- [ ] Prometheus scraping active
- [ ] Metrics dashboard populated
- [ ] Logs appear in centralized system
- [ ] Alerts configured and tested
- [ ] Notification channels working

## Operational Phase

### Day 1 Operations
- [ ] On-call engineer briefed on deployment
- [ ] Runbooks reviewed and accessible
- [ ] Escalation procedures communicated
- [ ] Known issues documented
- [ ] Incident response procedures active

### Week 1 Review
- [ ] System stability verified over 7 days
- [ ] Performance metrics reviewed
- [ ] Security logs audited for anomalies
- [ ] Error logs reviewed and addressed
- [ ] Resource utilization optimized

### Monthly Maintenance
- [ ] Security patches applied
- [ ] Database backups verified
- [ ] Disaster recovery drill conducted
- [ ] Logs archived appropriately
- [ ] Performance tuning review

## Rollback Procedure

If critical issues detected:

```bash
# 1. Stop current service
sudo systemctl stop aegisos

# 2. Restore previous version
cd /opt/aegisos
git checkout previous-tag

# 3. Rebuild
cargo build --release

# 4. Restore database backup (if needed)
# restore-db backup.sql

# 5. Start service
sudo systemctl start aegisos

# 6. Verify health
curl http://localhost:9001/health
```

## Performance SLAs

| Metric | Target | Alert Threshold |
|--------|--------|-----------------|
| API Response Time (p99) | <200ms | >500ms |
| Error Rate | <0.1% | >1% |
| Uptime | 99.95% | <99.9% |
| Database Query Time | <100ms | >500ms |
| Scan Success Rate | >99% | <98% |

## Support & Escalation

- **L1 Support**: On-call engineer
- **L2 Support**: Platform team (platform@your-org.com)
- **L3 Support**: Security team (security@your-org.com)

Emergency: Page on-call via PagerDuty

---
**Last Updated**: May 2024
**Version**: 1.0.0
**Maintained By**: Platform Engineering Team
