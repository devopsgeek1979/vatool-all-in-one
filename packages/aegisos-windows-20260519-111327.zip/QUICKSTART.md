# AegisOS Quick Start Guide

## 🚀 5-Minute Setup

### Prerequisites
- Rust 1.70+: `curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh`
- Docker (optional): https://www.docker.com/products/docker-desktop

### Local Development

```bash
# 1. Clone and navigate
git clone https://github.com/your-org/AegisOS.git
cd AegisOS

# 2. Build release binary
cargo build --release

# 3. Run tests (all should pass)
cargo test --all

# 4. Start daemon
./target/release/aegisosd

# In another terminal - test the API
curl http://localhost:9001/health
```

### Docker Deployment

```bash
# 1. Build and run with Docker Compose
docker-compose up -d

# 2. Check services
docker-compose ps

# 3. View logs
docker-compose logs -f aegisos

# Services are now available at:
# - API: http://localhost:9000
# - Metrics: http://localhost:9001
# - Prometheus: http://localhost:9090
# - Grafana: http://localhost:3000 (admin/admin)
```

## 📖 Common Tasks

### Scan a Package

```bash
# Using cURL
curl -X POST http://localhost:9000/api/v1/scan \
  -H "Content-Type: application/json" \
  -d '{
    "package": "lodash",
    "version": "4.17.20",
    "ecosystem": "npm"
  }'
```

### View Health Status

```bash
curl http://localhost:9001/health
```

### Get Prometheus Metrics

```bash
curl http://localhost:9001/metrics
```

### Production Installation

```bash
# 1. Build release
cargo build --release

# 2. Run installer (requires sudo)
sudo bash scripts/install.sh

# 3. Enable and start service
sudo systemctl start aegisos
sudo systemctl enable aegisos

# 4. Check status
sudo systemctl status aegisos

# 5. View logs
sudo journalctl -u aegisos -f

# 6. Complete first-run setup in the browser
#    Open https://localhost:9443/setup and create the Admin, Operator,
#    and Security Consultant accounts. The credential vault will be written
#    to /var/lib/aegisos/credentials.json with restrictive permissions.
```

## 🧪 Testing

```bash
# Run all tests
cargo test --all

# Run with output
cargo test --all -- --nocapture

# Run end-to-end tests
cargo test --test e2e_tests

# Run tests for specific crate
cargo test -p aegis-vuln
```

## 📊 Monitoring

### Local Metrics
- **Prometheus**: http://localhost:9090
- **Grafana**: http://localhost:3000
- **AegisOS Metrics**: http://localhost:9001/metrics

### Important Metrics
- `aegisos_scans_total` - Total scans completed
- `aegisos_vulnerabilities_found` - Total vulnerabilities found
- `aegisos_scan_duration_seconds` - Scan duration
- `aegisos_errors_total` - Total errors

## 🔧 Configuration

### Environment Variables

```bash
# Logging
export RUST_LOG=info

# Server
export AEGISOS_LISTEN_ADDR=0.0.0.0:9000
export AEGISOS_LOG_LEVEL=info

# Scanning
export AEGISOS_OSV_API_URL=https://api.osv.dev/v1
export AEGISOS_SCAN_TIMEOUT_SECS=300
export AEGISOS_MAX_CONCURRENT_SCANS=10
```

### Configuration File

See example in `crates/aegisosd/config.yaml`

### CIS Benchmarks

Open `https://localhost:9443/cis-benchmarks` after the first login to review
the hardening baseline mapped to the deployed package.

## 🆘 Troubleshooting

### Port Already in Use

```bash
# Check what's using the port
lsof -i :9000

# Kill the process
kill -9 <PID>
```

### Daemon Won't Start

```bash
# Check logs
journalctl -u aegisos -n 50

# Run daemon directly for debugging
./target/release/aegisosd
```

### Out of Memory

```bash
# Reduce concurrent scans
export AEGISOS_MAX_CONCURRENT_SCANS=5

# Monitor memory usage
watch -n 1 'ps aux | grep aegisosd'
```

## 📚 Documentation

- **Full README**: [README.md](README.md)
- **Deployment**: [DEPLOYMENT_CHECKLIST.md](docs/DEPLOYMENT_CHECKLIST.md)
- **Security**: [SECURITY.md](docs/SECURITY.md)
- **Contributing**: [CONTRIBUTING.md](CONTRIBUTING.md)
- **Test Report**: [TEST_REPORT.md](TEST_REPORT.md)

## 🤝 Getting Help

- **GitHub Issues**: Report bugs or request features
- **Documentation**: Check docs/ directory
- **Examples**: See tests/ for usage examples
- **Community**: [Discord](https://discord.gg/your-invite)

## ✨ Next Steps

1. **Read** the [README.md](README.md) for full documentation
2. **Try** the [DEPLOYMENT_CHECKLIST.md](docs/DEPLOYMENT_CHECKLIST.md) for production setup
3. **Review** [SECURITY.md](docs/SECURITY.md) for security best practices
4. **Check** [CONTRIBUTING.md](CONTRIBUTING.md) if interested in contributing

---

**Last Updated**: May 2024 | **Version**: 1.0.0
