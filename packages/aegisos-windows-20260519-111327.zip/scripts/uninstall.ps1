param(
  [string]$InstallRoot = "C:\Program Files\AegisOS",
  [string]$DataDir = "C:\ProgramData\AegisOS\data",
  [string]$LogDir = "C:\ProgramData\AegisOS\logs",
  [switch]$KeepData
)

$ErrorActionPreference = "Stop"

$principal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
  throw "Run this script in an elevated PowerShell session."
}

if (Get-Service aegisosd -ErrorAction SilentlyContinue) {
  sc.exe stop aegisosd | Out-Null
  sc.exe delete aegisosd | Out-Null
}

if (Test-Path $InstallRoot) {
  Remove-Item -Path $InstallRoot -Recurse -Force
}

if (-not $KeepData) {
  if (Test-Path $DataDir) { Remove-Item -Path $DataDir -Recurse -Force }
}

if (Test-Path $LogDir) {
  Remove-Item -Path $LogDir -Recurse -Force
}

Write-Host "Windows uninstall completed."
