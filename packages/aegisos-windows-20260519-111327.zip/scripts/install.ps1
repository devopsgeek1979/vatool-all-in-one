param(
  [string]$InstallRoot = "C:\Program Files\AegisOS",
  [string]$DataDir = "C:\ProgramData\AegisOS\data",
  [string]$LogDir = "C:\ProgramData\AegisOS\logs"
)

$ErrorActionPreference = "Stop"

function Ensure-Admin {
  $principal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
  if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw "Run this script in an elevated PowerShell session."
  }
}

function Install-Dependencies {
  if (Get-Command winget -ErrorAction SilentlyContinue) {
    winget install --id Microsoft.VCRedist.2015+.x64 --silent --accept-source-agreements --accept-package-agreements | Out-Null
    winget install --id Git.Git --silent --accept-source-agreements --accept-package-agreements | Out-Null
  } elseif (Get-Command choco -ErrorAction SilentlyContinue) {
    choco install vcredist140 git -y | Out-Null
  } else {
    Write-Host "Neither winget nor choco found. Install VC++ runtime manually if needed."
  }
}

Ensure-Admin
Install-Dependencies

New-Item -ItemType Directory -Force -Path $InstallRoot, $DataDir, $LogDir | Out-Null

$binarySource = Join-Path $PSScriptRoot "..\bin\aegisosd.exe"
$binaryTarget = Join-Path $InstallRoot "aegisosd.exe"

if (Test-Path $binarySource) {
  Copy-Item $binarySource $binaryTarget -Force
} elseif ($env:AEGISOS_WINDOWS_BINARY_URL) {
  Invoke-WebRequest -Uri $env:AEGISOS_WINDOWS_BINARY_URL -OutFile $binaryTarget
} else {
  throw "No Windows binary found in package. Set AEGISOS_WINDOWS_BINARY_URL and rerun."
}

[Environment]::SetEnvironmentVariable("AEGISOS_DATA_DIR", $DataDir, "Machine")
[Environment]::SetEnvironmentVariable("AEGISOS_LOG_DIR", $LogDir, "Machine")
[Environment]::SetEnvironmentVariable("RUST_LOG", "info", "Machine")

if (Get-Service aegisosd -ErrorAction SilentlyContinue) {
  sc.exe stop aegisosd | Out-Null
  sc.exe delete aegisosd | Out-Null
  Start-Sleep -Seconds 2
}

sc.exe create aegisosd binPath= "\"$binaryTarget\"" start= auto DisplayName= "AegisOS Security Daemon" | Out-Null
sc.exe start aegisosd | Out-Null

Write-Host "Windows deployment completed."
Write-Host "Setup page: https://localhost:9443/setup"
