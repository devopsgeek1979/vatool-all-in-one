#!/bin/bash

set -euo pipefail

INSTALL_DIR="${INSTALL_DIR:-/opt/aegisos}"
DATA_DIR="${DATA_DIR:-/usr/local/var/lib/aegisos}"
LOG_DIR="${LOG_DIR:-/usr/local/var/log/aegisos}"
SERVICE_LABEL="com.aegisos.daemon"
PLIST_PATH="/Library/LaunchDaemons/${SERVICE_LABEL}.plist"

if [[ $EUID -ne 0 ]]; then
  echo "Run as root (sudo)."
  exit 1
fi

if ! command -v brew >/dev/null 2>&1; then
  echo "Homebrew is required. Install from https://brew.sh"
  exit 1
fi

brew update
brew install curl jq gnu-tar coreutils || true

mkdir -p "$INSTALL_DIR" "$DATA_DIR" "$LOG_DIR"
touch "$DATA_DIR/credentials.json"
chmod 700 "$DATA_DIR"
chmod 600 "$DATA_DIR/credentials.json"

TARGET_BIN="/usr/local/bin/aegisosd"

if [[ -f "$(dirname "$0")/../bin/aegisosd" ]]; then
  install -m 755 "$(dirname "$0")/../bin/aegisosd" "$TARGET_BIN"
elif [[ -n "${AEGISOS_BINARY_URL:-}" ]]; then
  curl -fsSL "$AEGISOS_BINARY_URL" -o "$TARGET_BIN"
  chmod 755 "$TARGET_BIN"
else
  echo "No macOS binary bundled. Set AEGISOS_BINARY_URL and rerun."
  exit 1
fi

cat > "$PLIST_PATH" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
  <dict>
    <key>Label</key>
    <string>${SERVICE_LABEL}</string>
    <key>ProgramArguments</key>
    <array>
      <string>${TARGET_BIN}</string>
    </array>
    <key>EnvironmentVariables</key>
    <dict>
      <key>AEGISOS_DATA_DIR</key>
      <string>${DATA_DIR}</string>
      <key>AEGISOS_LOG_DIR</key>
      <string>${LOG_DIR}</string>
      <key>RUST_LOG</key>
      <string>info</string>
    </dict>
    <key>RunAtLoad</key>
    <true/>
    <key>KeepAlive</key>
    <true/>
    <key>StandardOutPath</key>
    <string>${LOG_DIR}/launchd.out.log</string>
    <key>StandardErrorPath</key>
    <string>${LOG_DIR}/launchd.err.log</string>
  </dict>
</plist>
PLIST

launchctl unload "$PLIST_PATH" >/dev/null 2>&1 || true
launchctl load -w "$PLIST_PATH"

echo "macOS deployment completed."
echo "Setup page: https://localhost:9443/setup"
