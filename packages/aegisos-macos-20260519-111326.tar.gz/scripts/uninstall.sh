#!/bin/bash

set -euo pipefail

SERVICE_LABEL="com.aegisos.daemon"
PLIST_PATH="/Library/LaunchDaemons/${SERVICE_LABEL}.plist"
TARGET_BIN="/usr/local/bin/aegisosd"
DATA_DIR="${DATA_DIR:-/usr/local/var/lib/aegisos}"
LOG_DIR="${LOG_DIR:-/usr/local/var/log/aegisos}"

if [[ $EUID -ne 0 ]]; then
  echo "Run as root (sudo)."
  exit 1
fi

launchctl unload "$PLIST_PATH" >/dev/null 2>&1 || true
rm -f "$PLIST_PATH"
rm -f "$TARGET_BIN"

if [[ "${KEEP_DATA:-false}" != "true" ]]; then
  rm -rf "$DATA_DIR"
fi

rm -rf "$LOG_DIR"

echo "macOS uninstall completed."
